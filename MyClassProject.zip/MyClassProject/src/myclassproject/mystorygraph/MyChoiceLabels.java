package myclassproject.mystorygraph;

//Fill this enum with the labels you chose for the EDGES of your story graph.

//Petra Radmanovic
public enum MyChoiceLabels {
	StartGame,
    HeadTowardTheLight,
    HeadDeeperIntoTheForest,
    ToTheCity,
    BackToForest,
    StayWithSword,
    RunToClearing,
    GoIntoCabin,
    WalkToStream,
    TalkToWiseMan, 
    
    //Hrishi Kabra
    PickUpApple
    
    /*SpeakToWiseMan,
    IgnoreTheWiseMan,
    PickAnApple,
    LeaveBasket,
    EatStrangeFruit,
    IgnoreStrangeFruit,
    ListenToWarning,
    IgnoreWarning,
    StruggleAgainstNet,
    StayStill,
    TalkToBandits,
    DemandAnswers,
    RunAway,
    PlayDead,
    FightBandits,
    Surrender
    */
    
    //Hrishi Kabra 
    
    
    //Rodrigo Guzman
}

