package myclassproject.questexample;

//Fill this enum with the labels you chose for the edges of your story graph.
public enum ChoiceLabels {
	Leave, TalkToBandit
}

