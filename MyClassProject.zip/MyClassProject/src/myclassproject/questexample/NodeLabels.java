package myclassproject.questexample;

public enum NodeLabels{
	root, atCottage, accept, accept2, refuse, inventory, atCity, atCity2, banditTalk, reset
}
